<template>
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>
</template>
