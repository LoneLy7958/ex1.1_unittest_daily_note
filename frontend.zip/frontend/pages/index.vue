<!-- pages/index.vue -->
<script setup>
navigateTo('/login')  // redirect ไปหน้า login
</script>
