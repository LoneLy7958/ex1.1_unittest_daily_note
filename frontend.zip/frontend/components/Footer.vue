<template>
  <footer class="bg-gray-800 text-white text-center p-4 text-sm">
    © 2025 DailyNotes by T̲̲a̲̲o̲̲. All rights reserved.
  </footer>
</template>
